# Instruksi 16
## instruksi 16.A

 Nomor Peserta : 3069
 Nama Peserta  : Rizky Setiawan


## instruksi 16.B

 Judul Sistem  : Form Pembelian Sparepart

## Isntruksi 16.C 

### MANUAL GUIDE   :
    
    1. Isi Inputan Sparepart Untuk memilih sparepart yang inggin di beli
    2. Isi inputan Nama Konsumen untuk menuliskan Nama Anda sebagai pembeli
    3. Isi jumlah untuk menentukan berapa banyak jumlah sparepart yang inggin anda beli
    4. Jika semua inputan sudah terisi tekan tombol SUBMIT untuk mengolah pesanan anda 
    5. Jika semua step di atas sudah dilakukan maka anda akan berpindah ke halaman selesai 
        untuk menampilkan hasil proses dari inputan yang anda inputkan 
    6. jika salah satu inputan atau semua inputan anda tidak terisi maka inputan tidak akan terperoses
        dan akan menampilkan pesan error